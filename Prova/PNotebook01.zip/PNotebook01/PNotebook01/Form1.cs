﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PNotebook01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // matriz 3x3
            decimal[,] notebooks = new decimal[3, 3];
            decimal[] totalPorDia = new decimal[3];

            string[] lojas = new string[] { "Loja 1", "Loja 2", "Loja 3" };

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    bool ok = false;
                    while (!ok)
                    {
                        string prompt = string.Format("Informe o valor na {0} para o modelo {1}:", lojas[i], j + 1);
                        string input = ShowInputBox(prompt, "Entrada de Valores", "0,00");

                        if (string.IsNullOrWhiteSpace(input))
                        {
                            notebooks[i, j] = 0m;
                            ok = true;
                        }
                        else
                        {
                            input = input.Trim();
                            input = input.Replace('.', ',');
                            decimal val;
                            if (decimal.TryParse(input, out val))
                            {
                                notebooks[i, j] = val;
                                ok = true;
                            }
                            else
                            {
                                var res = MessageBox.Show("Valor inválido. Deseja tentar novamente?", "Entrada inválida", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning);
                                if (res == DialogResult.Cancel)
                                {
                                    notebooks[i, j] = 0m;
                                    ok = true;
                                }
                            }
                        }
                    }
                }
            }

            decimal totalGeral = 0m;
            string[] vendasLojas = new string[3];

            for (int i = 0; i < 3; i++)
            {
                decimal soma = 0m;
                for (int j = 0; j < 3; j++)
                {
                    soma += notebooks[i, j];
                    vendasLojas[i] += $" Loja {i + 1}: R$ {notebooks[i, j]} ";
                }
                totalPorDia[i] = soma;
                totalGeral += soma;
            }

            listBox1.Items.Clear();
            for (int i = 0; i < 3; i++)
            {
                listBox1.Items.Add(string.Format("Notebook {0} - {1}: {2} Média: {3:N2}",i + 1, lojas[i], vendasLojas[i], totalPorDia[i] / 3));
            }
            listBox1.Items.Add("---------------------");
            listBox1.Items.Add(string.Format("Média Geral: {0:N2}", totalGeral / 9 ));
        }

        private string ShowInputBox(string prompt, string title, string defaultValue)
        {
            using (Form form = new Form())
            {
                form.Width = 400;
                form.Height = 150;
                form.Text = title;
                form.FormBorderStyle = FormBorderStyle.FixedDialog;
                form.StartPosition = FormStartPosition.CenterParent;
                form.MinimizeBox = false;
                form.MaximizeBox = false;

                Label lbl = new Label() { Left = 10, Top = 10, Text = prompt, AutoSize = true };
                TextBox txt = new TextBox() { Left = 10, Top = 35, Width = 360, Text = defaultValue };
                Button btnOk = new Button() { Text = "OK", Left = 220, Width = 70, Top = 70, DialogResult = DialogResult.OK };
                Button btnCancel = new Button() { Text = "Cancelar", Left = 300, Width = 70, Top = 70, DialogResult = DialogResult.Cancel };

                form.Controls.Add(lbl);
                form.Controls.Add(txt);
                form.Controls.Add(btnOk);
                form.Controls.Add(btnCancel);
                form.AcceptButton = btnOk;
                form.CancelButton = btnCancel;

                var result = form.ShowDialog();
                if (result == DialogResult.OK)
                    return txt.Text;
                else
                    return string.Empty;
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
    }
}
